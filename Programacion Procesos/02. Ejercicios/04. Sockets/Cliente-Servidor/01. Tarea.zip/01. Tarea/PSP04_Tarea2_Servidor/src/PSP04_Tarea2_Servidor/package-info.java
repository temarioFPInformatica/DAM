/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/package-info.java to edit this template
 */
/**
 * <strong>Tarea para PSP04</strong><br>
 * Proyecto que resuelve la tarea 2, el apartado referido al servidor,de la
 * asignatura de Programación de Servicios y Procesos, del C.F.G.S. Desarrollo
 * de Aplicaciones Multiplataforma, en la modalidad a distancia, del I.E.S.
 * Augusto González de Linares, en el curso 2022/2023.
 *
 * @author Diego González García
 */
package PSP04_Tarea2_Servidor;
